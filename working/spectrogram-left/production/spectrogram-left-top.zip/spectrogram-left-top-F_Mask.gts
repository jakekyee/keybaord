G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-05-09T21:17:45-07:00*
G04 #@! TF.ProjectId,spectrogram-left-top,73706563-7472-46f6-9772-616d2d6c6566,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-05-09 21:17:45*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.600000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X88260000Y-20450000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X22210000Y-21060000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X154970000Y-20430000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X159740000Y-123680000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X90640000Y-123700000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X22190000Y-123070000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X21620000Y-72080000D03*
G04 #@! TD*
M02*
