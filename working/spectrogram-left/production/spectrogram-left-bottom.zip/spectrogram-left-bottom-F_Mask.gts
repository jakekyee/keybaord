G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-05-09T21:14:10-07:00*
G04 #@! TF.ProjectId,spectrogram-left-bottom,73706563-7472-46f6-9772-616d2d6c6566,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-05-09 21:14:10*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.600000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X165381026Y-21970229D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X165971026Y-72990229D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X165401026Y-123980229D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X96951026Y-124610229D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X27851026Y-124590229D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X32621026Y-21340229D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X99331026Y-21360229D03*
G04 #@! TD*
M02*
