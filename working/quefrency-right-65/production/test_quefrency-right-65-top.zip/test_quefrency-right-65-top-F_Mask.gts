G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-05-10T08:44:37-07:00*
G04 #@! TF.ProjectId,test_quefrency-right-65-top,74657374-5f71-4756-9566-72656e63792d,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-05-10 08:44:37*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.600000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X132885890Y-30628068D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X218310890Y-31208068D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X218900890Y-82258068D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X135255890Y-133928068D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X47430890Y-30608068D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X218320890Y-133258068D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X52270890Y-133888068D03*
G04 #@! TD*
M02*
